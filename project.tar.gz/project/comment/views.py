from django.shortcuts import render
from django.http import HttpResponseRedirect,HttpResponse
from django import template
from django.template import loader
from django.template.loader import get_template
from django.shortcuts import get_object_or_404, render
from django.core.urlresolvers import reverse



from django.http import HttpResponse

from .models import Comment, Reply, Food



def add_comment(request, food_id):

    if request.method == 'POST':
        comment = request.POST.get('comment')
        form = Comment(comment=comment, food_id=food_id)  # if form.is_valid():
        form.save()
        food_list = Food.objects.all()
        comment_list = Comment.objects.all()
        reply_list = Reply.objects.all()
        context = {'form': form, 'food_list': food_list, 'comment_list': comment_list,'reply_list': reply_list}
        return render(request, 'comment/food.html',context)

    else:
        form = Comment()
        return render(request, 'comment/index.html', {'form': form, 'food': food_id})


def detail(request):
    food_list = Food.objects.order_by('?')
    reply_list = Reply.objects.all()
    comment_list = Comment.objects.all()
    context = {'food_list': food_list, 'comment_list': comment_list, 'reply_list': reply_list}
    return render(request, 'comment/food.html', context)


def add_reply(request, comment_id):

    if request.method == 'POST':
        reply = request.POST.get('reply')
        form = Reply(reply=reply, comment_id=comment_id)
        form.save()
        food_list = Food.objects.all()
        comment_list = Comment.objects.all()
        reply_list = Reply.objects.all()
        context = {'form': form, 'food_list': food_list, 'comment_list': comment_list, 'reply_list': reply_list}
        return render(request, 'comment/food.html', context)


    else:
        form = Reply()
        return render(request, 'comment/detail.html', {'form': form, 'comment': comment_id})