from django.conf.urls import url

from . import views

urlpatterns = [

   url(r'^(?P<food_id>[0-9]+)/add_comment/$', views.add_comment, name='add_comment'),
   url(r'^$', views.detail, name='detail'),

   url(r'^(?P<comment_id>[0-9]+)/add_reply/$', views.add_reply, name='add_reply'),


]